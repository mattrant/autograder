print "hello autolob"
print "{\"scores\": {\"Test\":100}}"
